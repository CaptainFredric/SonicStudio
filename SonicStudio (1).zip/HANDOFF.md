# SonicStudio · First-Impression Sequence — Handoff

**Live mockup:** `SonicStudio First Impression.html` (5-frame design canvas with interactive 2→3→4 prototype)
**Drop-in patches against `CaptainFredric/SonicStudio @ main`:**
- `index.html`
- `src/components/BrandMark.tsx`
- `src/components/TopBar.tsx`

Drop those three files into the repo, `npm run build`, push — redesign is live.

**Locked inputs from brief:** palette `#04070b` / `#72d9ff` / `#ff9c8a` / `#e4bf6a`, IBM Plex Sans + Mono, 64px grid + radial glows, 230ms cubic-bezier(.22,1,.36,1) motion.

---

## What's delivered

### 5 hi-fi frames (design canvas, side-by-side)
| # | Frame | Size | Notes |
|---|---|---|---|
| 01 | Boot splash | 1280×800 | Replaces "LOADING SONICSTUDIO" wordmark with animated layered-wave glyph + determinate progress + scanning shimmer. |
| 02 | Studio · Audio LOCKED | 1280×800 | Centered hero CTA "Wake audio & play". Both old prompts removed. Spec callouts overlay this frame. |
| 03 | Studio · Audio UNLOCKED, IDLE | 1280×800 | CTA dismissed; Play stays hero in top bar; chrome calmer. |
| 04 | Studio · PLAYING | 1280×800 | Playhead advancing, meters live, meta-chip row + Pattern Bank fade in. |
| 05 | Mobile · LOCKED | 375×812 | Hero CTA above the fold, no scroll required to make a sound. |

### Live prototype
- Frames 02 → 03 → 04 share one DOM (`InteractiveStudio` component). Click the cyan CTA on frame 02 to wake; click Play in the top bar to start; click again to cycle back. State transitions all run on the 230ms motion token.
- Each frame is independently focusable in the design canvas (click the expand button on an artboard).

### Spec callouts (frame 02 only)
Six labeled annotations call out the four design bets directly on the artboard.

---

## Design decisions made

| Brief decision | Choice |
|---|---|
| Collapse the two play-nudges | Killed BOTH the top-right "Wake Audio" panel AND the bottom-left "Press ▶" hint. A single centered hero CTA owns the moment. Cleaner than either alternative the brief listed. |
| Defer meta-chip row | Hidden on locked + idle. Fades in (230ms) only on first transition to PLAYING. |
| Defer Pattern Bank A/B/C/D + Count In | Same gate as meta chips. New users don't see them; returning users do once playback proves context. |
| Make Play visibly louder | Top-bar Play uses solid accent fill, larger height (36px vs 30px), pulse ring, and outer glow on locked/idle. Undo/Redo/Save/Options drop to 42% opacity until first play, then equalize. |

### Surface tweaks beyond the brief
- Animated brand mark: three layered sine waves redrawn each rAF tick. Used at 92px on splash (speed 1.6), 22px in top bar wordmarks (speed 1). Respects `prefers-reduced-motion`.
- Bar/beat counter + 00:04:12 elapsed timer appear in the bottom rack only on PLAYING — confirms the bet paid off.
- Track-name dots in left rail glow + soft-pulse only when their clips are sounding.
- Master meter dB readout swaps from `–∞` → `–6.2 dB` and `○ silent` → `◉ live` on PLAYING.

---

## What I think should be done next

### 1 · Validate against the live hydrated app
I designed against the brief and the boot-splash screenshot you shared. Send screenshots of:
- The hydrated studio frame at desktop width (the actual top-bar icon set, panel proportions, library sidebar contents).
- The current device-rack bottom strip.
- Any extant inspector/master panel.
Then I can match exact iconography, spacing, and panel chrome 1:1.

### 2 · Wire the splash → frame 02 transition
Currently the splash is a static frame and frame 02 is reachable by focusing it. Worth wiring the splash to auto-advance after ~1.2s (or on hydration-ready signal) inside one continuous prototype, so the boot → first-frame motion can be reviewed as a sequence.

### 3 · Define the "after first play" equalization curve
The brief says Undo/Redo/Save/Options "can equalize" after first play. I've matched that. Worth a separate review of whether the file group should equalize fully or stay slightly demoted indefinitely — currently a binary opacity flip; could be a softer 70% target.

### 4 · Empty-state copy on the inspector
Right rail currently shows "Lead · Synth · Pulse Mk II" as default selection on cold start. Probably want a true empty state on locked ("Select a track") since the user hasn't engaged anything yet. Quick win.

### 5 · Mobile transport beyond the hero
Frame 05 only covers the locked state. Worth a frame 06 (mobile · playing) showing how the hero CTA collapses into a fixed bottom transport bar, since that's the biggest layout question for mobile.

### 6 · Reduced-motion audit
Wave animation, pulse ring, CTA glow, meter bars all honor `prefers-reduced-motion` already. But the playhead progresses regardless — it should stop animating and instead advance in 1-bar discrete steps under reduced motion.

### 7 · Dark-light parity (out of scope, flagging)
Brief locks dark only. If a light theme ever ships, the hero-CTA glow strategy needs rethinking — radial cyan blur reads as "weather" on light backgrounds.

---

## File structure

```
SonicStudio First Impression.html  ← entry point (open this)
studio.jsx                          ← all SonicStudio components (TopBar, Arranger, etc.)
design-canvas.jsx                   ← starter component, canvas wrapper
HANDOFF.md                          ← this file
CHANGELOG.md                        ← chronological change log
```

Open the HTML in a browser — no build step. Babel-standalone transpiles the JSX in place.

---

## Out of scope (per brief)

- Sequencer, Piano Roll, Mixer, Arranger interior layouts
- Settings sidebar
- Device-rack bottom strip (exists in mocks as a thin status bar only — not a redesign)
- Sound design, marketing copy, app-store assets

---

## Open questions for you

1. Should the splash hold for a fixed minimum (e.g. 1.2s) or dismiss as soon as audio worklet is ready, even if that's <300ms?
2. Is "Wake audio & play" the right CTA copy? Alternatives: "Tap to start", "Start session", "Press ▶ to play".
3. After first play, should the file group icons equalize to 100% or stay at ~70%?
4. The brief defers Count In on first run — does it surface on second visit, or only when the user toggles record?
