# Changelog

## v2.0 — Patches against the real repo (CaptainFredric/SonicStudio @ main)

Pulled the live source from GitHub and produced drop-in replacements that wire the redesign into the actual app.

**`src/components/BrandMark.tsx`** — rewritten as a live sine-wave generator. Three layered curves redraw each rAF tick at staggered phases. Same `className` API as before, plus optional `speed` and `amplitude` props. Falls back to a static frame under `prefers-reduced-motion`. The TopBar uses `speed={isPlaying ? 1.4 : 1}` so the mark visibly accelerates while playback is live.

**`index.html`** — boot splash redesigned. The three static wave paths now animate via `@keyframes` `path()` morphing on staggered delays, wrapped in a soft cyan radial glow. Adds a determinate progress track (62%) with a scanning shimmer, an "IBM Plex Mono / Loading audio worklet" label, and a "Browser-native composition" wordmark at the bottom. All animations honor `prefers-reduced-motion`. Theme color updated `#07111A` → `#04070b` to match the in-app surface.

**`src/components/TopBar.tsx`** — first-impression behavior wired to the existing `isFirstImpression` flag (`!isInitialized && !isPlaying`):
- Pattern bank A/B/C/D row hidden on cold start; returns after first play.
- Mini-stats row (Track/Pattern/Clip/Profile/Master) hidden on cold start; returns after first play.
- Undo / Redo / Save group dimmed to 42% opacity on cold start; equalizes to 100% after first play.
- "Wake audio" chip removed on cold start so it cannot compete with the hero Play button. The Play button itself wakes audio via `togglePlay → initAudio`. Chip returns once initialized so the user can re-arm if the browser suspends sound.
- Audio block copy updated: "Sound is asleep. Wake audio or hit play to start." → "Press play above to wake audio."

These four files are the entire patch surface. Drop them into the repo, `npm run build`, and the redesign is live.

## v1.2 — Animated brand wave + studio polish
- **BrandMark** rewritten as live sine-wave generator. Three layered curves redraw each rAF tick at staggered phases. Used at 92px on splash (speed 1.6) and 22px in every top-bar wordmark (speed 1). Falls back to a static initial frame under `prefers-reduced-motion`.
- Splash inline SVG removed; now uses the live `BrandMark` component for visual continuity with the in-app wordmark.
- PLAYING frame: added 00:04:12 elapsed timer alongside the bar/beat counter in the bottom rack — visible only when transport is live, confirms the bet paid off.

## v1.1 — Cleanup
- Removed the stray "Design notes" post-it section from the canvas; the spec callouts on frame 02 already carry the rationale.

## v1.0 — Initial delivery
**5 hi-fi frames + interactive 2→3→4 prototype.**

Built:
- `BootSplash` — replaces "LOADING SONICSTUDIO" wordmark with cyan layered-wave glyph + determinate progress + scanning shimmer + version pill.
- `StudioFrame(state)` — single component driving frames 02 / 03 / 04 via `state` prop (locked / idle / playing).
- `HeroCTA` — centered modal-style CTA "Tap to wake the audio engine" with cyan accent button, pulse ring, blurred radial blob. Replaces both the top-right "Audio is asleep / Wake Audio" panel and the bottom-left "Press ▶ or hit space" hint.
- `TopBar` — Undo / Redo / Save / Options demoted to 42% opacity on locked + idle. Play button: solid cyan fill, 36px height, pulse ring, outer glow. After first play, file group equalizes to 85%.
- `LeftRail` — Library categories + Session tracks. Track dots glow + pulse on PLAYING when their clips are sounding.
- `Arranger` — 4 tracks × 16 bars. Clip waveforms animate per-bar on PLAYING; playhead releases (idle) and advances at 6%/s (playing).
- `RightRail` — Inspector panel (Lead · Synth · Pulse Mk II) + Master meter pair + dB readout that swaps `–∞` → `–6.2 dB` and `○ silent` → `◉ live` on PLAYING.
- `BottomRack` — Audio engine status pill, CPU, buffer, bar/beat. Status dot pulses warning-yellow on locked, accent-cyan otherwise.
- `MobileFrame` — 375×812 mobile of locked state. Hero CTA above the fold, no scroll required to make a sound.
- `SpecCallouts` — 6 labeled annotations overlaying frame 02 only.
- `InteractiveStudio` — wraps `StudioFrame` with state machine: locked → idle → playing → locked.

Hidden on cold start (deferred until first PLAYING):
- Meta-chip row (TRACK / PATTERN / CLIP / PROFILE / MASTER)
- Pattern Bank A/B/C/D
- Count In (never surfaced in mockups; flagged in handoff)

Honors `prefers-reduced-motion` on: brand wave, pulse rings, CTA blob, panel fades. Playhead advance still animates — flagged as a follow-up in handoff.
