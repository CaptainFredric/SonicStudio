import React, { useEffect, useState } from 'react';
import { useAudio } from '../context/AudioContext';

/**
 * FirstRunCoachmark
 *
 * A single, dismissible floating coachmark that appears on cold start, points
 * to the Play button in the TopBar, and disappears the moment the user wakes
 * audio (or clicks the dismiss x). Designed to be the *only* nudge — it
 * replaces both the "Wake Audio" panel and the "Press ▶" hint.
 *
 * Drop into the workspace tree once, after <TopBar />:
 *
 *   import { FirstRunCoachmark } from './components/FirstRunCoachmark';
 *   …
 *   <TopBar />
 *   <FirstRunCoachmark />
 *
 * Persists dismissal in localStorage so returning users never see it twice.
 * Honors prefers-reduced-motion.
 */
export const FirstRunCoachmark: React.FC = () => {
  const { isInitialized, isPlaying } = useAudio();
  const [dismissed, setDismissed] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return window.localStorage.getItem('ss-coachmark-dismissed') === '1';
  });

  // Auto-dismiss the moment the user crosses the first-play threshold.
  useEffect(() => {
    if ((isInitialized || isPlaying) && !dismissed) {
      setDismissed(true);
      window.localStorage.setItem('ss-coachmark-dismissed', '1');
    }
  }, [isInitialized, isPlaying, dismissed]);

  if (dismissed || isInitialized || isPlaying) return null;

  const dismiss = () => {
    setDismissed(true);
    window.localStorage.setItem('ss-coachmark-dismissed', '1');
  };

  return (
    <>
      <style>{`
        @keyframes ss-coach-in {
          from { opacity: 0; transform: translateY(-4px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes ss-coach-bob {
          0%, 100% { transform: translateY(0); }
          50%      { transform: translateY(-3px); }
        }
        .ss-coach {
          position: fixed;
          z-index: 50;
          top: calc(var(--ss-topbar-h, 168px) + 12px);
          right: 28px;
          max-width: 280px;
          padding: 14px 16px;
          background: rgba(8, 11, 16, 0.96);
          border: 1px solid rgba(114, 217, 255, 0.32);
          border-radius: 10px;
          box-shadow: 0 18px 48px rgba(0, 0, 0, 0.5),
                      0 0 0 1px rgba(114, 217, 255, 0.08),
                      0 0 60px rgba(114, 217, 255, 0.18);
          color: #e7eef6;
          font-size: 12.5px;
          line-height: 1.45;
          backdrop-filter: blur(10px);
          animation: ss-coach-in 280ms cubic-bezier(0.22, 1, 0.36, 1) both;
        }
        .ss-coach::before {
          content: '';
          position: absolute;
          top: -7px;
          right: 92px;
          width: 12px;
          height: 12px;
          background: rgba(8, 11, 16, 0.96);
          border-top: 1px solid rgba(114, 217, 255, 0.32);
          border-left: 1px solid rgba(114, 217, 255, 0.32);
          transform: rotate(45deg);
        }
        .ss-coach-eyebrow {
          font-family: 'IBM Plex Mono', ui-monospace, monospace;
          font-size: 9px;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: #72d9ff;
          margin-bottom: 6px;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .ss-coach-eyebrow .dot {
          width: 6px; height: 6px; border-radius: 50%;
          background: #72d9ff;
          animation: ss-coach-bob 1.6s ease-in-out infinite;
        }
        .ss-coach-title { font-weight: 600; letter-spacing: -0.01em; margin-bottom: 4px; }
        .ss-coach-body { color: rgba(231, 238, 246, 0.62); font-size: 11.5px; }
        .ss-coach-x {
          position: absolute; top: 8px; right: 8px;
          width: 22px; height: 22px;
          display: inline-flex; align-items: center; justify-content: center;
          background: transparent; border: 0; cursor: pointer;
          color: rgba(231, 238, 246, 0.38);
          border-radius: 4px;
          transition: color 140ms, background 140ms;
        }
        .ss-coach-x:hover { color: #e7eef6; background: rgba(255,255,255,0.04); }
        @media (prefers-reduced-motion: reduce) {
          .ss-coach { animation: none; }
          .ss-coach-eyebrow .dot { animation: none; }
        }
      `}</style>
      <div className="ss-coach" role="status" aria-live="polite">
        <button className="ss-coach-x" onClick={dismiss} aria-label="Dismiss tip">×</button>
        <div className="ss-coach-eyebrow"><span className="dot" /> Ready when you are</div>
        <div className="ss-coach-title">Press play to wake audio</div>
        <div className="ss-coach-body">A 4-bar Lead + Bass loop is staged so you'll hear something the moment audio comes online.</div>
      </div>
    </>
  );
};
