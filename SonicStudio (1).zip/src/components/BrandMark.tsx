import React, { useEffect, useRef, useState } from 'react';

/**
 * BrandMark — animated layered cyan waves.
 *
 * Three sine paths recompute each rAF tick at staggered phases / amplitudes,
 * so the mark "breathes" instead of sitting static. Falls back to the initial
 * frame under prefers-reduced-motion.
 *
 * Drop-in replacement: same className API as the previous static version.
 */
export const BrandMark = ({
  className = 'h-5 w-5',
  speed = 1,
  amplitude = 1,
}: {
  className?: string;
  /** Animation speed multiplier. 1 = default; bump to 1.4–1.8 for the splash. */
  speed?: number;
  /** Amplitude multiplier. Useful when the mark is rendered very large. */
  amplitude?: number;
}) => {
  const [phase, setPhase] = useState(0);
  const reducedRef = useRef(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reducedRef.current = mq.matches;
    if (reducedRef.current) return;

    let raf = 0;
    let start = 0;
    const tick = (t: number) => {
      if (!start) start = t;
      setPhase(((t - start) / 1000) * speed);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [speed]);

  const buildPath = (
    yMid: number,
    amp: number,
    freq: number,
    phaseOffset: number,
  ) => {
    const steps = 28;
    const x0 = 16;
    const w = 32;
    const a = amp * amplitude;
    let d = `M ${x0} ${yMid + Math.sin(phase + phaseOffset) * a}`;
    for (let i = 1; i <= steps; i++) {
      const x = x0 + (i / steps) * w;
      const y =
        yMid +
        Math.sin(phase * 1.4 + phaseOffset + (i / steps) * freq * Math.PI * 2) *
          a;
      d += ` L ${x.toFixed(2)} ${y.toFixed(2)}`;
    }
    return d;
  };

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 64 64"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        fill="currentColor"
        fillOpacity="0.08"
        height="52"
        rx="10"
        width="52"
        x="6"
        y="6"
      />
      <path
        d={buildPath(22, 3.0, 1.6, 0)}
        stroke="currentColor"
        strokeLinecap="round"
        strokeOpacity="0.45"
        strokeWidth="4.5"
      />
      <path
        d={buildPath(32, 3.4, 1.4, 1.1)}
        stroke="currentColor"
        strokeLinecap="round"
        strokeOpacity="0.75"
        strokeWidth="4.5"
      />
      <path
        d={buildPath(42, 3.6, 1.2, 2.3)}
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="4.5"
      />
    </svg>
  );
};
