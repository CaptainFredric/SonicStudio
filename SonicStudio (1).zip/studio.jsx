// studio.jsx — SonicStudio first-impression sequence
// Three desktop states (locked / idle / playing), plus splash and mobile.

const SS_VARS = {
  bg: '#04070b',
  panelBorder: 'rgba(149,169,189,0.10)',
  panelBorderStrong: 'rgba(149,169,189,0.18)',
  panelBg: 'rgba(8,11,16,0.9)',
  panelBgSoft: 'rgba(14,20,28,0.6)',
  accent: '#72d9ff',
  accentSoft: 'rgba(114,217,255,0.16)',
  accentDim: 'rgba(114,217,255,0.45)',
  danger: '#ff9c8a',
  warning: '#e4bf6a',
  ink: '#e7eef6',
  inkDim: 'rgba(231,238,246,0.62)',
  inkFaint: 'rgba(231,238,246,0.38)',
  inkGhost: 'rgba(231,238,246,0.18)',
  motion: '230ms cubic-bezier(0.22,1,0.36,1)',
  font: '"IBM Plex Sans", system-ui, -apple-system, sans-serif',
  mono: '"IBM Plex Mono", ui-monospace, SFMono-Regular, monospace',
};

// One-time CSS for SonicStudio surface
if (typeof document !== 'undefined' && !document.getElementById('ss-styles')) {
  const s = document.createElement('style');
  s.id = 'ss-styles';
  s.textContent = `
    .ss-root{position:absolute;inset:0;background:${SS_VARS.bg};color:${SS_VARS.ink};
      font-family:${SS_VARS.font};font-size:13px;line-height:1.4;overflow:hidden;
      letter-spacing:-0.005em;
      -webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
    .ss-root *{box-sizing:border-box}
    .ss-mono{font-family:${SS_VARS.mono};text-transform:uppercase;letter-spacing:0.18em;font-weight:500}
    .ss-grid-bg{position:absolute;inset:0;pointer-events:none;
      background-image:
        linear-gradient(${SS_VARS.panelBorder} 1px, transparent 1px),
        linear-gradient(90deg, ${SS_VARS.panelBorder} 1px, transparent 1px);
      background-size:64px 64px;opacity:0.55;mask-image:radial-gradient(ellipse at center, #000 30%, transparent 80%);}
    .ss-glow-tr{position:absolute;top:-220px;right:-180px;width:640px;height:640px;border-radius:50%;
      background:radial-gradient(circle, rgba(114,217,255,0.18), rgba(114,217,255,0) 65%);pointer-events:none;}
    .ss-glow-bl{position:absolute;bottom:-260px;left:-220px;width:720px;height:720px;border-radius:50%;
      background:radial-gradient(circle, rgba(114,217,255,0.10), rgba(114,217,255,0) 65%);pointer-events:none;}
    .ss-panel{background:${SS_VARS.panelBg};border:1px solid ${SS_VARS.panelBorder};border-radius:14px;
      backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);}
    .ss-icon-btn{width:30px;height:30px;display:inline-flex;align-items:center;justify-content:center;
      background:transparent;border:1px solid transparent;border-radius:8px;color:${SS_VARS.inkDim};cursor:pointer;
      transition:background ${SS_VARS.motion}, color ${SS_VARS.motion}, border-color ${SS_VARS.motion};}
    .ss-icon-btn:hover{background:rgba(255,255,255,0.04);color:${SS_VARS.ink};border-color:${SS_VARS.panelBorder}}
    .ss-icon-btn.is-armed{color:${SS_VARS.danger}}
    .ss-icon-btn.is-faint{color:${SS_VARS.inkFaint}}
    .ss-pulse-ring{position:absolute;inset:-6px;border-radius:50%;border:1px solid ${SS_VARS.accentDim};
      animation:ss-pulse 1.6s ease-out infinite;pointer-events:none}
    @keyframes ss-pulse{0%{transform:scale(0.92);opacity:0.9}100%{transform:scale(1.35);opacity:0}}
    @keyframes ss-pulse-soft{0%,100%{opacity:0.45}50%{opacity:1}}
    @keyframes ss-bar{0%{transform:scaleY(0.2)}50%{transform:scaleY(1)}100%{transform:scaleY(0.4)}}
    @keyframes ss-meter{0%{transform:scaleY(0.25)}50%{transform:scaleY(0.95)}100%{transform:scaleY(0.55)}}
    @keyframes ss-fade-in{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
    @keyframes ss-scan{0%{transform:translateX(-30%)}100%{transform:translateX(130%)}}
    .ss-fade-in{animation:ss-fade-in ${SS_VARS.motion} both}
    .ss-cta-blob{position:absolute;inset:-30px;border-radius:50%;
      background:radial-gradient(circle, rgba(114,217,255,0.28), rgba(114,217,255,0) 70%);
      filter:blur(10px);pointer-events:none;animation:ss-pulse-soft 2.4s ease-in-out infinite;}
    @media (prefers-reduced-motion:reduce){
      .ss-pulse-ring,.ss-cta-blob{animation:none !important}
    }
  `;
  document.head.appendChild(s);
}

// --- Brand mark: layered cyan waves, animated -------------------------------
// Three sine waves at staggered phases. Phase advances via rAF so the curves
// breathe; animation stalls under prefers-reduced-motion (initial phase only).
function BrandMark({ size = 22, strokeWidth, speed = 1, idle = false }) {
  const [phase, setPhase] = React.useState(0);
  const reduced = React.useRef(false);

  React.useEffect(()=>{
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    reduced.current = mq.matches;
    if (idle || reduced.current) return;
    let raf, start;
    const tick = (t)=>{
      if (!start) start = t;
      setPhase((t - start) / 1000 * speed);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return ()=> cancelAnimationFrame(raf);
  }, [idle, speed]);

  // Build a sine path across the 32-unit viewBox
  const buildPath = (amp, freq, phaseOffset, yMid)=>{
    const steps = 24;
    const w = 28;
    const x0 = 2;
    let d = `M ${x0} ${yMid + Math.sin(phase + phaseOffset) * amp}`;
    for (let i = 1; i <= steps; i++) {
      const x = x0 + (i / steps) * w;
      const y = yMid + Math.sin(phase * 1.4 + phaseOffset + (i / steps) * freq * Math.PI * 2) * amp;
      d += ` L ${x.toFixed(2)} ${y.toFixed(2)}`;
    }
    return d;
  };

  const sw = strokeWidth ?? Math.max(1.2, size * 0.06);
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true"
      style={{ overflow:'visible' }}>
      <path d={buildPath(3.0, 1.6, 0,        18)}
        stroke={SS_VARS.accent} strokeWidth={sw} strokeLinecap="round" strokeOpacity="0.35"/>
      <path d={buildPath(3.4, 1.4, 1.1,      15)}
        stroke={SS_VARS.accent} strokeWidth={sw} strokeLinecap="round" strokeOpacity="0.65"/>
      <path d={buildPath(3.6, 1.2, 2.3,      12)}
        stroke={SS_VARS.accent} strokeWidth={sw} strokeLinecap="round"/>
    </svg>
  );
}

function Wordmark({ size = 14 }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:8 }}>
      <BrandMark size={size + 8}/>
      <span style={{ fontWeight:700, letterSpacing:'-0.01em', fontSize:size, color:SS_VARS.ink }}>
        SonicStudio
      </span>
    </span>
  );
}

// --- Tiny inline icons ------------------------------------------------------
const Ico = {
  Undo: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><path d="M3 8h7a3 3 0 0 1 0 6H6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="M5.5 5 3 8l2.5 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  Redo: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><path d="M13 8H6a3 3 0 0 0 0 6h4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="m10.5 5 2.5 3-2.5 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  Save: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><path d="M3 3h8l2 2v8a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="currentColor" strokeWidth="1.3"/><path d="M5 3v3h5V3M5 14v-4h6v4" stroke="currentColor" strokeWidth="1.3"/></svg>,
  Options: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><circle cx="3" cy="8" r="1.3" fill="currentColor"/><circle cx="8" cy="8" r="1.3" fill="currentColor"/><circle cx="13" cy="8" r="1.3" fill="currentColor"/></svg>,
  Record: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><circle cx="8" cy="8" r="4" fill="currentColor"/></svg>,
  Stop: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><rect x="4" y="4" width="8" height="8" rx="1" fill="currentColor"/></svg>,
  Play: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><path d="M5 3.5v9l8-4.5z" fill="currentColor"/></svg>,
  PlayLg: (p)=> <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...p}><path d="M8 5v14l11-7z" fill="currentColor"/></svg>,
  Pause: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><rect x="4" y="3.5" width="3" height="9" fill="currentColor"/><rect x="9" y="3.5" width="3" height="9" fill="currentColor"/></svg>,
  Plus: (p)=> <svg width="12" height="12" viewBox="0 0 12 12" fill="none" {...p}><path d="M6 1.5v9M1.5 6h9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>,
  Volume: (p)=> <svg width="14" height="14" viewBox="0 0 16 16" fill="none" {...p}><path d="M3 6v4h2.5L9 13V3L5.5 6H3Z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"/><path d="M11 6c.7.7.7 3.3 0 4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>,
  Sparkle: (p)=> <svg width="12" height="12" viewBox="0 0 12 12" fill="none" {...p}><path d="M6 1.5 6.9 4.6 10 5.5 6.9 6.4 6 9.5 5.1 6.4 2 5.5l3.1-.9z" fill="currentColor"/></svg>,
};

// --- Top bar ----------------------------------------------------------------
function TopBar({ state, onPlay, onStop }) {
  // state: 'locked' | 'idle' | 'playing'
  const playIsHero = state === 'locked' || state === 'idle';
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:14,
      padding:'12px 18px', borderBottom:`1px solid ${SS_VARS.panelBorder}`,
      background:'rgba(4,7,11,0.6)', backdropFilter:'blur(10px)',
      position:'relative', zIndex:5,
    }}>
      <Wordmark size={13}/>
      <div style={{ width:1, height:18, background:SS_VARS.panelBorder, marginLeft:6 }}/>

      {/* File group — visibly demoted on first frame, equal weight after first play */}
      <div style={{ display:'flex', gap:2, opacity: playIsHero ? 0.42 : 0.85, transition:`opacity ${SS_VARS.motion}` }}>
        <button className="ss-icon-btn is-faint" title="Undo"><Ico.Undo/></button>
        <button className="ss-icon-btn is-faint" title="Redo"><Ico.Redo/></button>
        <button className="ss-icon-btn is-faint" title="Save"><Ico.Save/></button>
        <button className="ss-icon-btn is-faint" title="Options"><Ico.Options/></button>
      </div>

      {/* Center: project name */}
      <div style={{
        flex:'1 1 auto', display:'flex', alignItems:'center', justifyContent:'center', gap:10,
        fontSize:12, color:SS_VARS.inkDim,
      }}>
        <span style={{ color:SS_VARS.inkFaint }}>untitled session</span>
        <span style={{ color:SS_VARS.inkGhost }}>·</span>
        <span className="ss-mono" style={{ fontSize:10, color:SS_VARS.inkFaint }}>120 BPM · 4/4</span>
      </div>

      {/* Transport — Play is hero on locked/idle */}
      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
        <button className="ss-icon-btn is-armed" title="Record" style={{ opacity: playIsHero ? 0.42 : 0.85 }}>
          <Ico.Record/>
        </button>
        <PlayButton state={state} onPlay={onPlay} onStop={onStop}/>
      </div>
    </div>
  );
}

function PlayButton({ state, onPlay, onStop }) {
  const isPlaying = state === 'playing';
  const isHero = state === 'locked' || state === 'idle';
  const label = isPlaying ? 'Pause' : 'Play';
  const onClick = isPlaying ? onStop : onPlay;

  return (
    <div style={{ position:'relative' }}>
      <button
        onClick={onClick}
        title={label}
        style={{
          display:'inline-flex', alignItems:'center', gap:8,
          height: isHero ? 36 : 30,
          padding: isHero ? '0 16px' : '0 12px',
          borderRadius: isHero ? 10 : 8,
          background: isHero ? SS_VARS.accent : 'rgba(114,217,255,0.10)',
          color: isHero ? '#04141d' : SS_VARS.accent,
          border: isHero ? '1px solid rgba(255,255,255,0.18)' : `1px solid ${SS_VARS.panelBorder}`,
          fontFamily:SS_VARS.mono, fontWeight:600, fontSize: isHero ? 11 : 10,
          letterSpacing:'0.18em', textTransform:'uppercase',
          cursor:'pointer',
          boxShadow: isHero
            ? '0 0 0 1px rgba(114,217,255,0.5), 0 8px 30px rgba(114,217,255,0.32), inset 0 1px 0 rgba(255,255,255,0.35)'
            : 'none',
          transition:`all ${SS_VARS.motion}`,
        }}
      >
        {isPlaying ? <Ico.Pause/> : <Ico.PlayLg style={{ width: isHero?16:13, height: isHero?16:13 }}/>}
        <span>{label}</span>
      </button>
      {isHero && <span className="ss-pulse-ring" style={{ borderRadius:10 }}/>}
    </div>
  );
}

// --- Left sidebar (browser) -------------------------------------------------
function LeftRail({ state }) {
  const items = ['Synths', 'Drums', 'Loops', 'Vocals', 'Stems', 'Effects'];
  return (
    <aside style={{
      width:200, padding:'18px 14px',
      borderRight:`1px solid ${SS_VARS.panelBorder}`,
      display:'flex', flexDirection:'column', gap:14,
      background:'rgba(4,7,11,0.45)',
    }}>
      <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint }}>Library</div>
      <div style={{ display:'flex', flexDirection:'column', gap:2 }}>
        {items.map((it,i)=>(
          <div key={it} style={{
            display:'flex', alignItems:'center', gap:10,
            padding:'7px 10px', borderRadius:7,
            color: i===0 ? SS_VARS.ink : SS_VARS.inkDim,
            background: i===0 ? 'rgba(255,255,255,0.04)' : 'transparent',
            fontSize:12.5,
          }}>
            <span style={{
              width:6, height:6, borderRadius:'50%',
              background: i===0 ? SS_VARS.accent : SS_VARS.inkGhost,
            }}/>
            <span>{it}</span>
            <span style={{ marginLeft:'auto', fontSize:10, color:SS_VARS.inkFaint, fontFamily:SS_VARS.mono }}>
              {[124, 86, 220, 41, 12, 58][i]}
            </span>
          </div>
        ))}
      </div>

      <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint, marginTop:8 }}>Session</div>
      <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
        {['Lead', 'Bass', 'Drums', 'Pad'].map((t,i)=>(
          <div key={t} style={{
            display:'flex', alignItems:'center', gap:8, fontSize:12,
            color: state==='playing' && i<2 ? SS_VARS.ink : SS_VARS.inkDim,
            opacity: state==='locked' ? 0.7 : 1,
            transition:`opacity ${SS_VARS.motion}`,
          }}>
            <span style={{
              width:18, height:14, borderRadius:3,
              background: state==='playing' && i<2 ? SS_VARS.accentSoft : 'rgba(255,255,255,0.04)',
              border:`1px solid ${SS_VARS.panelBorder}`,
            }}/>
            <span>{t}</span>
          </div>
        ))}
        <button style={{
          marginTop:4, display:'inline-flex', alignItems:'center', gap:6,
          padding:'6px 8px', borderRadius:6, background:'transparent',
          border:`1px dashed ${SS_VARS.inkGhost}`, color:SS_VARS.inkFaint,
          fontFamily:SS_VARS.font, fontSize:11.5, cursor:'pointer',
        }}>
          <Ico.Plus/> add track
        </button>
      </div>
    </aside>
  );
}

// --- Right rail (inspector) -------------------------------------------------
function RightRail({ state }) {
  return (
    <aside style={{
      width:240, padding:'18px 16px',
      borderLeft:`1px solid ${SS_VARS.panelBorder}`,
      display:'flex', flexDirection:'column', gap:18,
      background:'rgba(4,7,11,0.45)',
    }}>
      <div>
        <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint, marginBottom:10 }}>Inspector</div>
        <div className="ss-panel" style={{ padding:14, borderRadius:10 }}>
          <div style={{ fontSize:13, color:SS_VARS.ink, marginBottom:4 }}>Lead · Synth</div>
          <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint }}>Pulse Mk II · A4</div>
          <div style={{ marginTop:14, display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            {['Cutoff','Reso','Drive','Pan'].map((k,i)=>(
              <div key={k}>
                <div className="ss-mono" style={{ fontSize:8, color:SS_VARS.inkFaint, marginBottom:6 }}>{k}</div>
                <div style={{
                  height:4, borderRadius:2, background:'rgba(255,255,255,0.05)',
                  position:'relative', overflow:'hidden',
                }}>
                  <div style={{
                    position:'absolute', inset:0,
                    width:`${[68,42,55,50][i]}%`,
                    background:SS_VARS.accentDim,
                    borderRadius:2,
                  }}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div>
        <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint, marginBottom:10 }}>Master</div>
        <div className="ss-panel" style={{ padding:14, borderRadius:10, display:'flex', gap:14 }}>
          <Meter active={state==='playing'} idx={0}/>
          <Meter active={state==='playing'} idx={1}/>
          <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'space-between' }}>
            <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint }}>OUT</div>
            <div style={{ fontSize:18, fontWeight:600, color:SS_VARS.ink, letterSpacing:'-0.02em' }}>
              {state==='playing' ? '–6.2' : '–∞'}
              <span style={{ fontSize:10, color:SS_VARS.inkFaint, marginLeft:4 }}>dB</span>
            </div>
            <div className="ss-mono" style={{ fontSize:8, color: state==='playing' ? SS_VARS.accent : SS_VARS.inkFaint }}>
              {state==='playing' ? '◉ live' : '○ silent'}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}

function Meter({ active, idx }) {
  const segs = 16;
  return (
    <div style={{ width:8, display:'flex', flexDirection:'column-reverse', gap:2 }}>
      {Array.from({length:segs}).map((_,i)=>{
        const lit = active && i < (idx===0 ? 11 : 9);
        const peak = active && i === (idx===0 ? 12 : 10);
        return (
          <div key={i} style={{
            height:5, borderRadius:1,
            background: lit
              ? (i>11 ? SS_VARS.warning : SS_VARS.accent)
              : peak ? SS_VARS.inkGhost : 'rgba(255,255,255,0.04)',
            opacity: lit ? (active ? 1 : 0.4) : 1,
            animation: active && lit ? `ss-meter ${0.4 + idx*0.15 + i*0.04}s ease-in-out infinite alternate` : 'none',
            transformOrigin:'bottom',
          }}/>
        );
      })}
    </div>
  );
}

// --- Center: timeline / arranger -------------------------------------------
function Arranger({ state, playhead }) {
  const tracks = [
    { name:'Lead',  clips:[[1,4], [6,9]],   color:SS_VARS.accent },
    { name:'Bass',  clips:[[1,12]],          color:'#9ad0e5' },
    { name:'Drums', clips:[[1,16]],          color:'#c2e8f5' },
    { name:'Pad',   clips:[[3,7], [10,15]],  color:'rgba(114,217,255,0.6)' },
  ];
  const bars = 16;

  return (
    <div style={{ flex:1, padding:'18px 22px 0', position:'relative' }}>
      {/* Bar ruler */}
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        marginBottom:10, paddingLeft:80,
      }}>
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${bars}, 1fr)`, flex:1, gap:0 }}>
          {Array.from({length:bars}).map((_,i)=>(
            <div key={i} className="ss-mono" style={{
              fontSize:9, color: i%4===0 ? SS_VARS.inkDim : SS_VARS.inkFaint,
              textAlign:'left', paddingLeft:2,
            }}>{i%4===0 ? i+1 : '·'}</div>
          ))}
        </div>
      </div>

      {/* Tracks */}
      <div style={{ position:'relative' }}>
        {tracks.map((t, ti)=>(
          <div key={t.name} style={{
            display:'flex', alignItems:'center', height:42,
            borderTop: ti===0 ? `1px solid ${SS_VARS.panelBorder}` : 'none',
            borderBottom:`1px solid ${SS_VARS.panelBorder}`,
          }}>
            <div style={{
              width:80, paddingRight:12, display:'flex', alignItems:'center', gap:8,
              fontSize:12, color:SS_VARS.inkDim,
            }}>
              <span style={{
                width:6, height:6, borderRadius:'50%',
                background: state==='playing' && ti<3 ? t.color : SS_VARS.inkGhost,
                boxShadow: state==='playing' && ti<3 ? `0 0 8px ${t.color}` : 'none',
                animation: state==='playing' && ti<3 ? 'ss-pulse-soft 1.4s ease-in-out infinite' : 'none',
              }}/>
              {t.name}
            </div>
            <div style={{
              flex:1, position:'relative', height:30, borderRadius:6,
              background:'rgba(255,255,255,0.015)',
              border:`1px solid ${SS_VARS.panelBorder}`,
              overflow:'hidden',
            }}>
              {t.clips.map((c,ci)=>{
                const left = ((c[0]-1)/bars)*100;
                const width = ((c[1]-c[0])/bars)*100;
                return (
                  <div key={ci} style={{
                    position:'absolute', top:3, bottom:3,
                    left:`${left}%`, width:`${width}%`,
                    borderRadius:4,
                    background: state==='playing'
                      ? `linear-gradient(180deg, ${t.color}, ${SS_VARS.accentSoft})`
                      : 'rgba(149,169,189,0.10)',
                    border:`1px solid ${state==='playing' ? t.color : SS_VARS.panelBorderStrong}`,
                    opacity: state==='locked' ? 0.5 : (state==='idle' ? 0.7 : 1),
                    transition:`all ${SS_VARS.motion}`,
                    overflow:'hidden',
                  }}>
                    <ClipWaveform active={state==='playing' && ti<3} seed={ti*7+ci}/>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {/* Playhead */}
        {state !== 'locked' && (
          <div style={{
            position:'absolute', top:-4, bottom:0,
            left:`calc(80px + ${playhead}% * (100% - 80px) / 100)`,
            width:1, background: state==='playing' ? SS_VARS.accent : SS_VARS.inkGhost,
            boxShadow: state==='playing' ? `0 0 12px ${SS_VARS.accent}` : 'none',
            pointerEvents:'none', transition: state==='playing' ? 'none' : `left ${SS_VARS.motion}`,
          }}>
            <div style={{
              position:'absolute', top:-6, left:-4, width:9, height:9,
              background:state==='playing' ? SS_VARS.accent : SS_VARS.inkGhost,
              borderRadius:'50% 50% 50% 0', transform:'rotate(-45deg)',
            }}/>
          </div>
        )}
      </div>
    </div>
  );
}

function ClipWaveform({ active, seed=0 }) {
  // Pseudo-random but deterministic bars
  const bars = 36;
  const rng = (i)=> {
    const x = Math.sin(seed*9.7 + i*1.3) * 10000;
    return Math.abs(x - Math.floor(x));
  };
  return (
    <div style={{
      position:'absolute', inset:0, display:'flex', alignItems:'center',
      gap:1, padding:'0 4px',
    }}>
      {Array.from({length:bars}).map((_,i)=>{
        const h = 30 + rng(i)*60;
        return (
          <div key={i} style={{
            flex:1, height:`${h}%`, minHeight:1,
            background: active ? 'rgba(255,255,255,0.55)' : 'rgba(255,255,255,0.22)',
            borderRadius:0.5,
            transformOrigin:'center',
            animation: active ? `ss-bar ${0.5 + rng(i)*0.6}s ease-in-out ${rng(i)*0.3}s infinite alternate` : 'none',
          }}/>
        );
      })}
    </div>
  );
}

// --- Bottom: device rack / status -------------------------------------------
function BottomRack({ state }) {
  return (
    <div style={{
      borderTop:`1px solid ${SS_VARS.panelBorder}`,
      padding:'10px 22px', display:'flex', alignItems:'center', gap:14,
      fontSize:11, color:SS_VARS.inkFaint, fontFamily:SS_VARS.mono,
      letterSpacing:'0.18em', textTransform:'uppercase',
      background:'rgba(4,7,11,0.5)',
    }}>
      <span style={{
        display:'inline-flex', alignItems:'center', gap:6,
        color: state==='locked' ? SS_VARS.warning : SS_VARS.accent,
      }}>
        <span style={{
          width:6, height:6, borderRadius:'50%', background:'currentColor',
          boxShadow:'0 0 6px currentColor',
          animation: state==='locked' ? 'ss-pulse-soft 1.6s ease-in-out infinite' : 'none',
        }}/>
        {state==='locked' ? 'Audio standby' : state==='playing' ? 'Audio engine · 48 kHz' : 'Audio ready · 48 kHz'}
      </span>
      <span style={{ color:SS_VARS.inkGhost }}>·</span>
      <span style={{ fontSize:10 }}>CPU 04%</span>
      <span style={{ color:SS_VARS.inkGhost }}>·</span>
      <span style={{ fontSize:10 }}>BUF 256</span>
      <span style={{ marginLeft:'auto', display:'inline-flex', alignItems:'center', gap:14, fontSize:10, color:SS_VARS.inkFaint }}>
        {state==='playing' && <span style={{ color:SS_VARS.accent }}>00 : 04 : 12</span>}
        <span>{state==='playing' ? 'BAR 3 · BEAT 2' : 'BAR 1 · BEAT 1'}</span>
      </span>
    </div>
  );
}

// --- Hero CTA overlay (locked state) ----------------------------------------
function HeroCTA({ onWake }) {
  return (
    <div style={{
      position:'absolute', inset:0, display:'flex',
      alignItems:'center', justifyContent:'center',
      background:'radial-gradient(ellipse at center, rgba(4,7,11,0.55), rgba(4,7,11,0.85))',
      backdropFilter:'blur(2px)', zIndex:20, animation:`ss-fade-in ${SS_VARS.motion} both`,
    }}>
      <div style={{
        position:'relative',
        display:'flex', flexDirection:'column', alignItems:'center', gap:18,
        textAlign:'center', maxWidth:420, padding:'28px 32px 30px',
        background:'rgba(8,11,16,0.85)',
        border:`1px solid ${SS_VARS.panelBorderStrong}`,
        borderRadius:18,
        boxShadow:'0 30px 80px rgba(0,0,0,0.55), 0 0 0 1px rgba(114,217,255,0.05)',
      }}>
        <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.accent }}>Ready when you are</div>
        <div style={{
          fontSize:22, fontWeight:600, color:SS_VARS.ink,
          letterSpacing:'-0.02em', lineHeight:1.2,
        }}>
          Tap to wake the audio engine
        </div>
        <div style={{ fontSize:13, color:SS_VARS.inkDim, lineHeight:1.5 }}>
          Browsers require one tap before they make sound.
          We've staged a 4-bar loop on Lead and Bass so you'll hear something the moment it's awake.
        </div>

        <div style={{ position:'relative', marginTop:6 }}>
          <span className="ss-cta-blob"/>
          <button
            onClick={onWake}
            style={{
              position:'relative',
              display:'inline-flex', alignItems:'center', gap:10,
              height:48, padding:'0 22px',
              borderRadius:12,
              background:SS_VARS.accent, color:'#04141d',
              border:'1px solid rgba(255,255,255,0.25)',
              fontFamily:SS_VARS.mono, fontWeight:600, fontSize:12,
              letterSpacing:'0.18em', textTransform:'uppercase',
              cursor:'pointer',
              boxShadow:'0 0 0 1px rgba(114,217,255,0.55), 0 12px 38px rgba(114,217,255,0.4), inset 0 1px 0 rgba(255,255,255,0.4)',
            }}
          >
            <Ico.PlayLg/>
            Wake audio &amp; play
          </button>
        </div>

        <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint, marginTop:2 }}>
          ⏎  or  Space
        </div>
      </div>
    </div>
  );
}

// --- Studio frame (states: locked / idle / playing) -------------------------
function StudioFrame({ state, onAdvance, screenLabel }) {
  const [playhead, setPlayhead] = React.useState(8);

  React.useEffect(()=>{
    if (state==='playing') {
      let raf;
      let start;
      const initial = playhead;
      const tick = (t)=>{
        if (!start) start = t;
        const dt = (t - start)/1000;
        const next = (initial + dt * 6) % 100; // 6%/s
        setPlayhead(next);
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      return ()=> cancelAnimationFrame(raf);
    }
    if (state==='idle') setPlayhead(0);
    if (state==='locked') setPlayhead(8);
  }, [state]);

  return (
    <div className="ss-root" data-screen-label={screenLabel}>
      <div className="ss-grid-bg"/>
      <div className="ss-glow-tr"/>
      <div className="ss-glow-bl"/>

      <div style={{ position:'relative', display:'flex', flexDirection:'column', height:'100%' }}>
        <TopBar state={state} onPlay={onAdvance} onStop={onAdvance}/>

        <div style={{ flex:1, display:'flex', minHeight:0 }}>
          <LeftRail state={state}/>
          <main style={{ flex:1, display:'flex', flexDirection:'column', minWidth:0, position:'relative' }}>
            <Arranger state={state} playhead={playhead}/>

            {/* Meta-chip row — DEFERRED until after first play */}
            {state === 'playing' && (
              <div style={{
                display:'flex', gap:8, padding:'14px 22px 6px', animation:`ss-fade-in ${SS_VARS.motion} both`,
              }}>
                {['Track','Pattern','Clip','Profile','Master'].map((c,i)=>(
                  <button key={c} className="ss-mono" style={{
                    padding:'6px 12px', borderRadius:999,
                    background: i===0 ? SS_VARS.accentSoft : 'rgba(255,255,255,0.03)',
                    border:`1px solid ${i===0 ? SS_VARS.accentDim : SS_VARS.panelBorder}`,
                    color: i===0 ? SS_VARS.accent : SS_VARS.inkDim,
                    fontSize:9, cursor:'pointer',
                  }}>{c}</button>
                ))}
                <div style={{
                  marginLeft:'auto', display:'flex', alignItems:'center', gap:8, fontSize:10,
                  color:SS_VARS.inkFaint, fontFamily:SS_VARS.mono, letterSpacing:'0.18em', textTransform:'uppercase',
                }}>
                  Pattern Bank
                  {['A','B','C','D'].map((k,i)=>(
                    <button key={k} style={{
                      width:24, height:22, borderRadius:5,
                      border:`1px solid ${i===0 ? SS_VARS.accentDim : SS_VARS.panelBorder}`,
                      background: i===0 ? SS_VARS.accentSoft : 'transparent',
                      color: i===0 ? SS_VARS.accent : SS_VARS.inkDim,
                      fontFamily:SS_VARS.mono, fontSize:10, cursor:'pointer',
                    }}>{k}</button>
                  ))}
                </div>
              </div>
            )}

            <BottomRack state={state}/>
          </main>
          <RightRail state={state}/>
        </div>
      </div>

      {state === 'locked' && <HeroCTA onWake={onAdvance}/>}
    </div>
  );
}

// --- Boot splash ------------------------------------------------------------
function BootSplash({ screenLabel = '01 Boot Splash' }) {
  return (
    <div className="ss-root" data-screen-label={screenLabel} style={{ display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div className="ss-grid-bg" style={{ opacity:0.35 }}/>
      <div className="ss-glow-tr"/>
      <div className="ss-glow-bl"/>

      <div style={{
        position:'relative', display:'flex', flexDirection:'column', alignItems:'center', gap:26,
      }}>
        {/* Big mark */}
        <div style={{ position:'relative' }}>
          <div style={{
            position:'absolute', inset:-40, borderRadius:'50%',
            background:'radial-gradient(circle, rgba(114,217,255,0.22), rgba(114,217,255,0) 70%)',
            filter:'blur(8px)', animation:'ss-pulse-soft 2s ease-in-out infinite',
          }}/>
          <div style={{ position:'relative' }}>
            <BrandMark size={92} strokeWidth={1.4} speed={1.6}/>
          </div>
        </div>

        <div style={{ display:'flex', alignItems:'baseline', gap:10 }}>
          <span style={{ fontSize:34, fontWeight:700, letterSpacing:'-0.02em', color:SS_VARS.ink }}>SonicStudio</span>
          <span className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint, position:'relative', top:-3 }}>v 2.4</span>
        </div>

        {/* Determinate progress with scanning shimmer */}
        <div style={{ width:280, position:'relative' }}>
          <div style={{
            height:2, borderRadius:2, background:'rgba(149,169,189,0.10)', overflow:'hidden', position:'relative',
          }}>
            <div style={{
              position:'absolute', inset:0, width:'62%', background:SS_VARS.accentDim,
              borderRadius:2,
            }}/>
            <div style={{
              position:'absolute', top:0, bottom:0, width:'40%',
              background:`linear-gradient(90deg, transparent, ${SS_VARS.accent}, transparent)`,
              animation:'ss-scan 1.4s linear infinite',
            }}/>
          </div>
          <div style={{
            display:'flex', justifyContent:'space-between', marginTop:10,
            fontFamily:SS_VARS.mono, fontSize:9, color:SS_VARS.inkFaint,
            letterSpacing:'0.18em', textTransform:'uppercase',
          }}>
            <span>Loading audio worklet</span>
            <span>62%</span>
          </div>
        </div>
      </div>

      <div style={{
        position:'absolute', bottom:24, left:0, right:0, textAlign:'center',
        fontFamily:SS_VARS.mono, fontSize:9, color:SS_VARS.inkGhost,
        letterSpacing:'0.18em', textTransform:'uppercase',
      }}>
        Browser-native composition
      </div>
    </div>
  );
}

// --- Mobile frame -----------------------------------------------------------
function MobileFrame({ screenLabel = '05 Mobile · Locked', state = 'locked', onAdvance }) {
  const playing = state === 'playing';
  return (
    <div className="ss-root" data-screen-label={screenLabel}
      style={{ fontSize:13 }}
      onClick={onAdvance}>
      <div className="ss-grid-bg"/>
      <div className="ss-glow-tr"/>
      <div className="ss-glow-bl" style={{ bottom:-300, left:-260 }}/>

      <div style={{ position:'relative', display:'flex', flexDirection:'column', height:'100%' }}>
        {/* Status bar mock */}
        <div style={{
          height:44, padding:'0 22px', display:'flex', alignItems:'center', justifyContent:'space-between',
          fontSize:13, fontWeight:600, color:SS_VARS.ink,
        }}>
          <span>9:41</span>
          <span style={{ display:'flex', gap:5, alignItems:'center', color:SS_VARS.inkDim }}>
            <span style={{ display:'inline-block', width:16, height:10, border:`1px solid ${SS_VARS.inkDim}`, borderRadius:2 }}/>
          </span>
        </div>

        {/* Top bar */}
        <div style={{
          padding:'10px 18px', display:'flex', alignItems:'center', justifyContent:'space-between',
          borderBottom:`1px solid ${SS_VARS.panelBorder}`,
        }}>
          <Wordmark size={13}/>
          <button className="ss-icon-btn"><Ico.Options/></button>
        </div>

        {/* Bar ruler — compact */}
        <div style={{ padding:'14px 18px 6px' }}>
          <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.inkFaint, marginBottom:10 }}>untitled · 120 BPM</div>
          <div style={{ display:'flex', gap:4 }}>
            {Array.from({length:8}).map((_,i)=>(
              <div key={i} style={{
                flex:1, height:3, borderRadius:2,
                background: i<3 ? SS_VARS.accentDim : 'rgba(255,255,255,0.05)',
              }}/>
            ))}
          </div>
        </div>

        {/* Tracks — compact list */}
        <div style={{ flex:1, padding:'10px 18px', display:'flex', flexDirection:'column', gap:10 }}>
          {[
            { name:'Lead',  color:SS_VARS.accent, active:true },
            { name:'Bass',  color:'#9ad0e5', active:true },
            { name:'Drums', color:'#c2e8f5', active:playing },
            { name:'Pad',   color:'rgba(114,217,255,0.6)', active:playing },
          ].map((t,i)=>(
            <div key={t.name} style={{
              display:'flex', alignItems:'center', gap:12,
              padding:'10px 12px', borderRadius:10,
              background:'rgba(255,255,255,0.025)',
              border:`1px solid ${SS_VARS.panelBorder}`,
            }}>
              <span style={{
                width:8, height:8, borderRadius:'50%',
                background: t.active ? t.color : SS_VARS.inkGhost,
              }}/>
              <span style={{ color:SS_VARS.ink, fontWeight:500 }}>{t.name}</span>
              <div style={{ flex:1, height:18, position:'relative', borderRadius:4, overflow:'hidden',
                background:'rgba(255,255,255,0.02)',
              }}>
                <div style={{
                  position:'absolute', top:2, bottom:2, left:'8%', width:'72%',
                  borderRadius:3, background: t.active ? 'rgba(114,217,255,0.18)' : 'rgba(255,255,255,0.04)',
                  border:`1px solid ${t.active ? SS_VARS.accentDim : SS_VARS.panelBorder}`,
                }}>
                  <ClipWaveform active={false} seed={i*3+1}/>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom transport — hero on locked, compact bar on playing */}
        {playing ? (
          <div style={{
            padding:'12px 16px 16px',
            borderTop:`1px solid ${SS_VARS.panelBorder}`,
            background:'rgba(4,7,11,0.85)',
            display:'flex', alignItems:'center', gap:12,
          }}>
            <button style={{
              width:48, height:48, borderRadius:'50%',
              background:SS_VARS.accent, color:'#04141d',
              border:'1px solid rgba(255,255,255,0.25)',
              display:'inline-flex', alignItems:'center', justifyContent:'center',
              boxShadow:'0 0 0 1px rgba(114,217,255,0.45), 0 8px 24px rgba(114,217,255,0.3)',
              cursor:'pointer',
            }}>
              <Ico.Pause/>
            </button>
            <div style={{ flex:1, minWidth:0 }}>
              <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.accent }}>● Live · 48 kHz</div>
              <div style={{ fontSize:13, color:SS_VARS.ink, fontWeight:500, marginTop:2 }}>
                Bar 3 · Beat 2 <span style={{ color:SS_VARS.inkFaint, marginLeft:6, fontFamily:SS_VARS.mono, fontSize:11 }}>00:04:12</span>
              </div>
            </div>
            <button className="ss-icon-btn is-armed" style={{ width:36, height:36 }}><Ico.Record/></button>
          </div>
        ) : (
          <div style={{
            padding:'14px 18px 20px',
            borderTop:`1px solid ${SS_VARS.panelBorder}`,
            background:'linear-gradient(180deg, rgba(4,7,11,0) 0%, rgba(4,7,11,0.85) 30%)',
          }}>
            <div style={{ display:'flex', flexDirection:'column', gap:10, alignItems:'stretch' }}>
              <div className="ss-mono" style={{ fontSize:9, color:SS_VARS.accent, textAlign:'center' }}>
                Ready when you are
              </div>
              <div style={{
                fontSize:16, fontWeight:600, textAlign:'center',
                color:SS_VARS.ink, letterSpacing:'-0.01em', lineHeight:1.3,
              }}>
                Tap to wake audio &amp; play
              </div>
              <div style={{ position:'relative' }}>
                <span className="ss-cta-blob" style={{ inset:-24 }}/>
                <button style={{
                  position:'relative', width:'100%', height:54, borderRadius:14,
                  background:SS_VARS.accent, color:'#04141d',
                  border:'1px solid rgba(255,255,255,0.25)',
                  fontFamily:SS_VARS.mono, fontWeight:600, fontSize:13,
                  letterSpacing:'0.18em', textTransform:'uppercase',
                  display:'inline-flex', alignItems:'center', justifyContent:'center', gap:10,
                  boxShadow:'0 0 0 1px rgba(114,217,255,0.55), 0 14px 38px rgba(114,217,255,0.4), inset 0 1px 0 rgba(255,255,255,0.4)',
                  cursor:'pointer',
                }}>
                  <Ico.PlayLg/>
                  Wake audio &amp; play
                </button>
              </div>
              <div style={{
                display:'flex', justifyContent:'center', gap:18, marginTop:4,
                fontFamily:SS_VARS.mono, fontSize:9, color:SS_VARS.inkFaint,
                letterSpacing:'0.18em', textTransform:'uppercase',
              }}>
                <span>4-bar loop staged</span>
                <span style={{ color:SS_VARS.inkGhost }}>·</span>
                <span>48 kHz</span>
              </div>
            </div>
          </div>
        )}

        {/* Home indicator */}
        <div style={{ display:'flex', justifyContent:'center', padding:'4px 0 8px' }}>
          <div style={{ width:140, height:5, borderRadius:3, background:'rgba(255,255,255,0.18)' }}/>
        </div>
      </div>
    </div>
  );
}

// --- Spec callout ribbon (frame 2 only) -------------------------------------
function SpecCallouts() {
  const items = [
    { x:'50%', y:'46%', label:'A · Hero CTA', text:'Single play affordance — replaces the two competing nudges.' },
    { x:'90%', y:'10%', label:'B · Top-right panel', text:'"Wake Audio" panel removed. Less chrome competing with play.' },
    { x:'10%', y:'92%', label:'C · Bottom hint', text:'"Press ▶ or hit space" removed too — hero owns the moment.' },
    { x:'40%', y:'72%', label:'D · Meta chips', text:'Track / Pattern / Clip / Profile / Master deferred until after first play.' },
    { x:'80%', y:'72%', label:'E · Pattern bank', text:'A/B/C/D and Count In hidden on cold start. Returning users get them back.' },
    { x:'60%', y:'10%', label:'F · Demoted chrome', text:'Undo / Redo / Save / Options dimmed. Play visibly louder.' },
  ];
  return (
    <div style={{ position:'absolute', inset:0, pointerEvents:'none' }}>
      {items.map((it,i)=>(
        <div key={i} style={{
          position:'absolute', left:it.x, top:it.y, transform:'translate(-50%, -50%)',
          pointerEvents:'auto',
        }}>
          <div style={{
            display:'inline-flex', alignItems:'center', gap:8,
            padding:'6px 10px 6px 6px', borderRadius:999,
            background:'rgba(255,238,180,0.95)', color:'#3a2a05',
            fontFamily:SS_VARS.mono, fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase',
            fontWeight:600, boxShadow:'0 8px 24px rgba(0,0,0,0.4)',
            whiteSpace:'nowrap', maxWidth: 320,
          }}>
            <span style={{
              width:18, height:18, borderRadius:'50%', background:'#3a2a05', color:'#ffeeb4',
              display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:10,
            }}>{it.label.charAt(0)}</span>
            <span style={{
              fontFamily:SS_VARS.font, textTransform:'none', letterSpacing:'-0.005em',
              fontSize:11, fontWeight:500, color:'#1f1602',
            }}>{it.text}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

// --- Interactive prototype wrapper (cycles 2->3->4) -------------------------
function InteractiveStudio({ initial='locked', screenLabel }) {
  const [state, setState] = React.useState(initial);

  // Reset to initial when artboard re-mounts
  React.useEffect(()=>{ setState(initial); }, [initial]);

  const advance = ()=>{
    setState(prev => prev === 'locked' ? 'idle' : prev === 'idle' ? 'playing' : 'locked');
  };

  return <StudioFrame state={state} onAdvance={advance} screenLabel={screenLabel}/>;
}

// Export to window for canvas.jsx to consume
Object.assign(window, {
  BootSplash, StudioFrame, MobileFrame, InteractiveStudio, SpecCallouts,
});
